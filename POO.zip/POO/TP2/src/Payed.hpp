#ifndef PAYED_HPP
#define PAYED_HPP

class Payed {
public:
    void confirm();
    void cancel();
    void pay();
};

#endif 
