#ifndef FACTORYFLIGHTNUM_HPP
#define FACTORYFLIGHTNUM_HPP

#include "FlightNum.hpp"

class FactoryFlightNum {
public:
    static FlightNum GenFlightNum();
};

#endif // FACTORYFLIGHTNUM_HPP
