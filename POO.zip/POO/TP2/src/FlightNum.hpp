#ifndef FLIGHTNUM_HPP
#define FLIGHTNUM_HPP

class FlightNum {
private:
    int number;

public:
    FlightNum(int num);
    int getNumber() const;
    void setNumber(int num);
    
};

#endif 
